<<<<<<< .mine

//hashing
//#define PRIMETEST

//#define HASHTABLESIZE (unsigned long long)81474836321 //prime
// #define HASHTABLESIZE (unsigned long long)71474836319 //prime
  #define HASHTABLESIZE (unsigned long long)31474836311 //prime
//#define HASHTABLESIZE (unsigned long long)10147483639 //prime
//#define HASHTABLESIZE (unsigned long long)2147483647 //prime
//#define HASHTABLESIZE 1073676287 //prime
//#define HASHTABLESIZE	433494437 //prime
//#define HASHTABLESIZE 27644437 //prime
//#define HASHTABLESIZE 1299827 //prime
//#define HASHTABLESIZE 524287 //prime


#define BOOLHASH
#define NUMOFBITS 1

//multithreading
#define PTHREADS_ //if defined pthreads are used
#define PTHREADS 1

//options
#define GPUHASHING
=======

//hashing
//#define PRIMETEST

//#define HASHTABLESIZE (unsigned long long)81474836321 //prime
 #define HASHTABLESIZE (unsigned long long)71474836319 //prime
//  #define HASHTABLESIZE (unsigned long long)31474836311 //prime
//#define HASHTABLESIZE (unsigned long long)10147483639 //prime
//#define HASHTABLESIZE (unsigned long long)2147483647 //prime
//#define HASHTABLESIZE 1073676287 //prime
//#define HASHTABLESIZE	433494437 //prime
//#define HASHTABLESIZE 27644437 //prime
//#define HASHTABLESIZE 1299827 //prime
//#define HASHTABLESIZE 524287 //prime


//#define BOOLHASH
#define NUMOFBITS 15
//
//#define LLHASHING

//multithreading
#define PTHREADS 8


//options
//#define GPUHASHING
>>>>>>> .r254
