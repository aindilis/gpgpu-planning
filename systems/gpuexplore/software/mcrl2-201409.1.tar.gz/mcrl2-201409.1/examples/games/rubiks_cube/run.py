import os

os.system('mcrl22lps -vnD rubiks_cube.mcrl2 rubiks_cube.lps')

