import os

os.system('mcrl22lps -v magic_square.mcrl2 magic_square.lps')


