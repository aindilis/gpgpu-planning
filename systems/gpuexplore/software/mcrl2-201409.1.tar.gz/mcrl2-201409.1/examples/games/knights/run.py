import os

os.system('mcrl22lps -v knights.mcrl2 knights.lps')


