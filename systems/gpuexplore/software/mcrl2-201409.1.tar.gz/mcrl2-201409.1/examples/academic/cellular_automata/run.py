import os

os.system('mcrl22lps -v cellular_automata.mcrl2 cellular_automata.lps')




