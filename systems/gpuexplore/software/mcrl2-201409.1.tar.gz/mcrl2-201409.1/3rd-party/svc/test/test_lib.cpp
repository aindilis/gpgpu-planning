// empty test, just for testing if the libraries build correctly

#include <boost/test/minimal.hpp>

int test_main(int, char*[])
{
  return 0;
}
