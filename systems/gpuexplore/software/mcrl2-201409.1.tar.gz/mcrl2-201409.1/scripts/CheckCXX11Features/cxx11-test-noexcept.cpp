int test_noexcept() noexcept
{
  return 0;
}

int main()
{
  return test_noexcept();
}
