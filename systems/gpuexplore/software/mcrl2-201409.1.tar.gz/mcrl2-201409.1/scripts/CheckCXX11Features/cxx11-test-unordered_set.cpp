#include <unordered_set>

int main(void)
{
    std::unordered_set<int> s;
    s.insert(1);
    return 0;
}
