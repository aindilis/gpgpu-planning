#include <string>
#include <iostream>

int main()
{
  int i = 5;
  float f = 3.14159f;
  double d = 3.14159;
  std::cout << std::to_string(i) << std::endl;
  std::cout << std::to_string(f) << std::endl;
  std::cout << std::to_string(d) << std::endl;
  return 0;
}
