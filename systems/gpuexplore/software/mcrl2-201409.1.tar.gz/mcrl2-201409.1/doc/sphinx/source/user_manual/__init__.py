import tools

def generate_rst(temppath, outpath, binpath):
  tools.generate_rst(temppath, outpath, binpath)
