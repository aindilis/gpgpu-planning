Build performance
-----------------

.. figure:: http://www.mcrl2.org/performance/build_plots/recent/build.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/build_plots/all/build.svg>`_
