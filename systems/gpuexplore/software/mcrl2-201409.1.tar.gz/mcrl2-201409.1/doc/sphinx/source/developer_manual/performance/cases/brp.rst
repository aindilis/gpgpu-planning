brp
---

lps2lts
^^^^^^^

Time
""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/lps2lts/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/lps2lts/all/time.svg>`__

Memory
""""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/lps2lts/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/lps2lts/all/memory.svg>`__
   
mcrl22lps
^^^^^^^^^

Time
""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/mcrl22lps/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/mcrl22lps/all/time.svg>`__

Memory
""""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/mcrl22lps/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/mcrl22lps/all/memory.svg>`__
   
pbes2bool
^^^^^^^^^

Time
""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/pbes2bool/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/pbes2bool/all/time.svg>`__

Memory
""""""

.. figure:: http://www.mcrl2.org/performance/plots/cases/brp/pbes2bool/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/cases/brp/pbes2bool/all/memory.svg>`__
