.. index:: pbesinfo

.. _tool-pbesinfo:

pbesinfo
========

By default, the following information about the PBES is shown: 

* information if the PBES is closed and well-formed;
* number of equations, µs and νs.

