.. include:: toplevel.inc

.. _showcases:

Showcases
=========

mCRL2 or μCRL were used for the following case studies and examples.

.. toctree::
   :maxdepth: 1
   :glob:
    
   showcases/*
   
.. note:: This list is by no means complete.
   
A set of benchmark models that includes mCRL2 specifications is the
`BEEM collection <http://anna.fi.muni.cz/models/?page=models-list>`_.
