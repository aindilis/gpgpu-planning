pbes2bool
---------

Time
^^^^

``-pquantifier-all``
""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all/all/time.svg>`__
   
``-pquantifier-all -rinnerc``
"""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rinnerc/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rinnerc/all/time.svg>`__
   
``-pquantifier-all -rjittyc``
"""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rjittyc/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rjittyc/all/time.svg>`__
   
Memory
^^^^^^

``-pquantifier-all``
""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all/all/memory.svg>`__
   
``-pquantifier-all -rinnerc``
"""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rinnerc/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rinnerc/all/memory.svg>`__
   
``-pquantifier-all -rjittyc``
"""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rjittyc/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/pbes2bool/-pquantifier-all__-rjittyc/all/memory.svg>`__
