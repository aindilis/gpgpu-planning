mcrl22lps
---------

Time
^^^^

``-fD``
"""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-fD/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-fD/all/time.svg>`__
   
``-nfD``
""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-nfD/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-nfD/all/time.svg>`__
   
``default``
"""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/default/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/default/all/time.svg>`__
   
Memory
^^^^^^

``-fD``
"""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-fD/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-fD/all/memory.svg>`__
   
``-nfD``
""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-nfD/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/-nfD/all/memory.svg>`__
   
``default``
"""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/mcrl22lps/default/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/mcrl22lps/default/all/memory.svg>`__
