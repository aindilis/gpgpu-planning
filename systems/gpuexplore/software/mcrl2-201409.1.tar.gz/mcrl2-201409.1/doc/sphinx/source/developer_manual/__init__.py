import libraries

def generate_rst(temppath, outpath):
  libraries.generate_rst(temppath, outpath)
