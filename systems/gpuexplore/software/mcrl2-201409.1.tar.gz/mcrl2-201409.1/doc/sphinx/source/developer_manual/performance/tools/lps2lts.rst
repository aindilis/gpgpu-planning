lps2lts
-------

Time
^^^^

``default``
"""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/default/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/default/all/time.svg>`__

``-rjittyc``
""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc/all/time.svg>`__
   
``-rjittyc --cached --prune``
"""""""""""""""""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc__--alternative__--cached__--prune/recent/time.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc__--alternative__--cached__--prune/all/time.svg>`__      

Memory
^^^^^^

``default``
"""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/default/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/default/all/memory.svg>`__
   
``-rjittyc``
""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc/all/memory.svg>`__
   
``-rjittyc --cached --prune``
"""""""""""""""""""""""""""""""""""""""""""

.. figure:: http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc__--alternative__--cached__--prune/recent/memory.svg
   :align: center
   
   `Show plot of all measurements <http://www.mcrl2.org/performance/plots/tools/lps2lts/-rjittyc__--alternative__--cached__--prune/all/memory.svg>`__     
